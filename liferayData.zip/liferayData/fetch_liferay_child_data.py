#!/usr/bin/env python3
"""
Fetch missing Liferay child-object entries and M2M relationship data.

The original migrate.py only downloaded V3appmodule* entries.  All 477 child
object types (V3appsections, V3appwidget, V3apptopLeft, …) were never fetched,
so the tree structure is completely absent from the CMS.

This script:
  1. Discovers every child object referenced by any V3appmodule* definition.
  2. Downloads their entries via the Liferay REST API and saves them to
     liferayData/object-entries/{ObjectName}.json
  3. For each module entry, downloads the M2M relationship data (which child
     entries are linked to which module) and saves it to
     liferayData/relationships/{ObjectName}_{liferayEntryId}.json

After running this script, re-run migrate.py to import the new data.

Usage:
  python3 fetch_liferay_child_data.py            # fetch everything missing
  python3 fetch_liferay_child_data.py --dry-run  # print what would be fetched
"""

import json
import sys
import time
from pathlib import Path

import requests
from requests.auth import HTTPBasicAuth
import urllib3
import os

# Suppress only the single InsecureRequestWarning from urllib3 needed for verify=False
urllib3.disable_warnings(urllib3.exceptions.InsecureRequestWarning)

# ── Config ───────────────────────────────────────────────────────────────────

LIFERAY_BASE  = "https://cms-admin.internal.eg.vodafone.com"
LIFERAY_USER  = "mohamed.ramadan@vodafone.com"          # ← update if different
LIFERAY_PASS  = "Voda@2021"                    # ← update if different

LOCAL_DATA_DIR      = Path("liferayData")
ENTRY_DIR           = LOCAL_DATA_DIR / "object-entries"
RELATIONSHIP_DIR    = LOCAL_DATA_DIR / "relationships"
DEFINITIONS_FILE    = LOCAL_DATA_DIR / "object-definitions-all.json"

DRY_RUN    = "--dry-run" in sys.argv
PAGE_SIZE  = 200          # entries per Liferay page
SLEEP_MS   = 100          # ms between API calls to avoid rate-limiting

# ── Helpers ──────────────────────────────────────────────────────────────────

def liferay_auth():
    return HTTPBasicAuth(LIFERAY_USER, LIFERAY_PASS)


def get_proxies():
    """Return proxies dict for requests, using environment or hardcoded proxy if set."""
    # Prefer environment variables
    http_proxy = os.environ.get("HTTP_PROXY") or os.environ.get("http_proxy")
    https_proxy = os.environ.get("HTTPS_PROXY") or os.environ.get("https_proxy")
    if http_proxy or https_proxy:
        return {
            "http": http_proxy,
            "https": https_proxy or http_proxy,
        }
    # Optionally, set your proxy here if not using env vars:
    # return {"http": "http://proxy.example.com:8080", "https": "http://proxy.example.com:8080"}
    return None

def liferay_get_all(url: str, params: dict | None = None) -> list[dict]:
    """Paginate through a Liferay REST endpoint and return all items."""
    auth   = liferay_auth()
    items  = []
    page   = 1
    proxies = get_proxies()
    while True:
        p = {"page": page, "pageSize": PAGE_SIZE, **(params or {})}
        r = requests.get(url, auth=auth, params=p, timeout=30, verify=False, proxies=proxies)
        r.raise_for_status()
        try:
            body = r.json()
        except Exception as e:
            print(f"\n[DEBUG] Failed to parse JSON from {url}")
            print(f"[DEBUG] Response status: {r.status_code}")
            print(f"[DEBUG] Response headers: {dict(r.headers)}")
            print(f"[DEBUG] Response body (first 500 chars):\n{r.text[:500]}")
            raise
        batch = body.get("items", [])
        items.extend(batch)
        if len(items) >= body.get("totalCount", 0) or not batch:
            break
        page += 1
        time.sleep(SLEEP_MS / 1000)
    return items


def save_entries(obj_name: str, entries: list[dict]) -> None:
    ENTRY_DIR.mkdir(parents=True, exist_ok=True)
    out_path = ENTRY_DIR / f"{obj_name}.json"
    with open(out_path, "w", encoding="utf-8") as f:
        json.dump({"items": entries, "totalCount": len(entries)}, f, ensure_ascii=False, indent=2)
    print(f"   ✓ saved {len(entries)} entries → {out_path}")


def save_relationships(obj_name: str, entry_id: int, rel_name: str, children: list[dict]) -> None:
    RELATIONSHIP_DIR.mkdir(parents=True, exist_ok=True)
    out_path = RELATIONSHIP_DIR / f"{obj_name}_{entry_id}_{rel_name}.json"
    with open(out_path, "w", encoding="utf-8") as f:
        json.dump({"items": children, "totalCount": len(children)}, f, ensure_ascii=False, indent=2)


# ── Main ─────────────────────────────────────────────────────────────────────

def main() -> None:
    if DRY_RUN:
        print("⚠️  DRY RUN — no files will be written")

    # Load definitions
    print(f"📂 Loading object definitions from {DEFINITIONS_FILE}…")
    with open(DEFINITIONS_FILE, encoding="utf-8-sig") as f:
        all_defs: list[dict] = json.load(f).get("items", [])

    def_by_name = {o["name"]: o for o in all_defs}
    print(f"   {len(all_defs)} definitions loaded")

    # Collect all child object types referenced by any V3appmodule* definition
    module_defs = [o for o in all_defs if o["name"].lower().startswith("v3appmodule")]
    print(f"   {len(module_defs)} module definitions found")

    # Build: child_name → set of (module_name, relationship_name, restContextPath)
    child_map: dict[str, list[tuple[str, str]]] = {}
    for mod in module_defs:
        for rel in mod.get("objectRelationships", []):
            child_name = rel["objectDefinitionName2"]
            rel_name   = rel["name"]
            child_map.setdefault(child_name, []).append((mod["name"], rel_name))

    print(f"   {len(child_map)} unique child object types referenced")

    # ── Step 1: Download missing child entries ────────────────────────────────
    print("\n📥 Step 1: Downloading missing child object entries…")
    downloaded_names: set[str] = set()

    for child_name, usages in sorted(child_map.items()):
        out_path = ENTRY_DIR / f"{child_name}.json"
        if out_path.exists():
            print(f"   ↷ {child_name} — already exists, skipping")
            downloaded_names.add(child_name)
            continue

        child_def = def_by_name.get(child_name)
        if not child_def:
            print(f"   ✗ {child_name} — definition not found, skipping")
            continue

        rest_path = child_def.get("restContextPath", "")
        if not rest_path:
            print(f"   ✗ {child_name} — no restContextPath, skipping")
            continue

        url = f"{LIFERAY_BASE}{rest_path}"
        if DRY_RUN:
            print(f"   [DRY] Would fetch: GET {url}")
            downloaded_names.add(child_name)
            continue

        try:
            entries = liferay_get_all(url)
            save_entries(child_name, entries)
            downloaded_names.add(child_name)
        except Exception as e:
            print(f"   ✗ {child_name} — fetch failed: {e}")

    # ── Step 2: Download M2M relationship data for module entries ─────────────
    print("\n🔗 Step 2: Downloading M2M relationship data for all module entries…")

    for mod in module_defs:
        mod_name   = mod["name"]
        mod_rest   = mod.get("restContextPath", "")
        if not mod_rest:
            print(f"   ✗ {mod_name} — no restContextPath, skipping")
            continue

        # Load the module's own entries to get their Liferay IDs
        entry_file = ENTRY_DIR / f"{mod_name}.json"
        if not entry_file.exists():
            print(f"   ↷ {mod_name} — no entry file, skipping relationship fetch")
            continue

        with open(entry_file, encoding="utf-8-sig") as f:
            mod_entries = json.load(f).get("items", [])

        if not mod_entries:
            print(f"   {mod_name} — no entries found, skipping relationships")
            continue

        relationships = [r for r in mod.get("objectRelationships", []) if not r.get("reverse", False)]
        if not relationships:
            print(f"   {mod_name} — no relationships found, skipping")
            continue

        print(f"   {mod_name}: {len(mod_entries)} entries × {len(relationships)} relationships")

        for entry in mod_entries:
            entry_id = entry.get("id")
            pk_val   = entry.get("pk", entry_id)
            if not entry_id:
                print(f"   {mod_name} entry missing 'id', skipping")
                continue

            for rel in relationships:
                rel_name   = rel["name"]
                child_name = rel["objectDefinitionName2"]

                out_path = RELATIONSHIP_DIR / f"{mod_name}_{entry_id}_{rel_name}.json"
                if out_path.exists():
                    print(f"   ↷ Relationship file exists: {out_path.name}, skipping")
                    continue

                url = f"{LIFERAY_BASE}{mod_rest}/{entry_id}/{rel_name}"

                if DRY_RUN:
                    print(f"   [DRY] Would fetch: GET {url}  (pk={pk_val})")
                    continue

                print(f"   Fetching relationship: {mod_name}[{pk_val}] → {rel_name} ({url})")
                try:
                    children = liferay_get_all(url)
                    save_relationships(mod_name, entry_id, rel_name, children)
                    print(f"   ✓ {mod_name}[{pk_val}] → {rel_name}: {len(children)} children")
                    time.sleep(SLEEP_MS / 1000)
                except Exception as e:
                    print(f"   ✗ {mod_name}[{pk_val}].{rel_name}: {e}")

    print("\n✅ Done.")
    print("Next steps:")
    print("  1. Review liferayData/object-entries/ and liferayData/relationships/")
    print("  2. Run: python3 migrate.py  (to import the new child entries)")
    print("  3. Run: python3 migrate_relationships.py  (to link parents → children)")


if __name__ == "__main__":
    main()
 